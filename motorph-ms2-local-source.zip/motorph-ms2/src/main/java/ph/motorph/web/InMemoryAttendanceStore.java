package ph.motorph.web;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** Temporary raw attendance fixture. All entries and classifications are synthetic. */
public final class InMemoryAttendanceStore implements MutableAttendanceStore {
    private final List<AttendanceRecord> records;

    public InMemoryAttendanceStore() {
        List<AttendanceRecord> values = new ArrayList<>();
        values.add(record(5001, 101, "2026-10-01", "08:01", "17:00"));
        values.add(record(5002, 101, "2026-10-02", "07:58", "16:59"));
        values.add(record(5003, 101, "2026-10-15", "08:03", "17:01"));
        values.add(record(5101, 102, "2026-10-01", "08:00", "17:02"));
        values.add(record(5102, 102, "2026-10-03", "08:04", "17:03"));
        values.add(record(5201, 103, "2026-10-02", "08:10", "16:55"));
        records = values;
        enforceUniqueScheduleDate(records);
    }

    @Override
    public synchronized List<AttendanceRecord> findAll() {
        return new ArrayList<>(records);
    }

    @Override
    public synchronized List<AttendanceRecord> findByScheduleId(int scheduleId) {
        return records.stream()
            .filter(record -> record.getScheduleId() == scheduleId)
            .collect(Collectors.toList());
    }

    @Override
    public synchronized AttendanceRecord create(int scheduleId, LocalDate date, LocalTime timeIn,
                                                 LocalTime timeOut, String dayType) {
        for (AttendanceRecord existing : records) {
            if (existing.getScheduleId() == scheduleId && existing.getDate().equals(date)) {
                throw new IllegalStateException("A raw attendance record already exists for this synthetic schedule and date.");
            }
        }
        int nextId = records.stream().mapToInt(AttendanceRecord::getAttendanceId).max().orElse(0) + 1;
        if (nextId <= 0) throw new IllegalStateException("No synthetic attendance IDs remain in this process.");
        AttendanceRecord record = new AttendanceRecord(nextId, scheduleId, date, timeIn, timeOut, dayType);
        records.add(record);
        return record;
    }

    private static AttendanceRecord record(int attendanceId, int scheduleId, String date, String in, String out) {
        return new AttendanceRecord(attendanceId, scheduleId, LocalDate.parse(date),
            LocalTime.parse(in), LocalTime.parse(out), "DEMO");
    }

    private static void enforceUniqueScheduleDate(List<AttendanceRecord> records) {
        Set<String> keys = new HashSet<>();
        for (AttendanceRecord record : records) {
            String key = record.getScheduleId() + ":" + record.getDate();
            if (!keys.add(key)) throw new IllegalArgumentException("duplicate attendance for schedule/date: " + key);
        }
    }
}
